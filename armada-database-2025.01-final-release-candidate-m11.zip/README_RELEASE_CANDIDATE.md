﻿# Star Wars: Armada Structured Data - Milestone 11 Release Candidate

Baseline: 2025.01-final

Milestone 10:
- Imperial I-class Star Destroyer corrected 112 -> 110.

Milestone 11:
- Hera 28 vs 23 resolved as distinct identities; no correction.
- Official Onager corrections applied only from unambiguous AMG Errata 5.5 extraction.
- Onager writes applied: 0
- Onager official image-review holds: 2

Campaign exact-text source gate: 19
Text-sensitive Errata source gate: 4
