﻿# Source-Gated Backlog

This file is intentionally part of the release candidate.

## Official point confirmations
- Imperial I-class Star Destroyer
- Onager-class Star Destroyer
- Onager-class Testbed
- Hera Syndulla

## Campaign exact text
Open items: 19

## Text-sensitive Errata
- VCX-100 Freighter
- Lambda-class Shuttle
- Major Rhymer
- TIE Bomber Squadron

## Name collisions intentionally excluded from automatic point correction
- Lando Calrissian
- Hondo Ohnaka
