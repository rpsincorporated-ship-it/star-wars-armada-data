﻿# Star Wars: Armada Structured Data - Release Candidate

Baseline: **2025.01-final**

This release candidate contains the repository's validated structured Armada data
state after Milestones 1-8.

## Validation status

- Production JSON files: 191
- Parsed structured records: 349
- Duplicate stable IDs: 0
- Unsupported production rewrites: 0
- Release audit: PASS
- Classification: AUDIT-COMPLETE-WITH-SOURCE-GATED-BACKLOG

## Source policy

Official Atomic Mass Games / Fantasy Flight Games material is the authority for
official values and errata. Community-maintained sources can be used for
cross-checking but never independently authorize a production correction.

## Explicit unresolved source gates

Official point confirmations:
- Imperial I-class Star Destroyer
- Onager-class Star Destroyer
- Onager-class Testbed
- Hera Syndulla

Campaign objective exact-text items open: 19

Text-sensitive Errata candidates:
- VCX-100 Freighter
- Lambda-class Shuttle
- Major Rhymer
- TIE Bomber Squadron

Name-collision holds:
- Lando Calrissian
- Hondo Ohnaka

These items are intentionally disclosed rather than guessed.
