﻿param([string]$ReleaseRoot=(Split-Path -Parent $MyInvocation.MyCommand.Path))
$ErrorActionPreference='Stop'
$Data=Join-Path $ReleaseRoot 'data'
$Manifest=Get-Content -LiteralPath (Join-Path $ReleaseRoot 'RELEASE_MANIFEST.json') -Raw|ConvertFrom-Json
$Files=@(Get-ChildItem -LiteralPath $Data -Recurse -File -Filter '*.json'|Sort-Object FullName)
if($Files.Count-ne191){throw ('Expected 191 JSON files; found '+$Files.Count)}
$Records=0;$Ids=@{};$Dup=@()
foreach($F in $Files){
 $X=Get-Content -LiteralPath $F.FullName -Raw|ConvertFrom-Json
 $A=if($X-is[System.Array]){@($X)}else{@($X)}
 $Records+=@($A).Count
 foreach($R in @($A)){
  if($null-ne$R-and$R.PSObject.Properties.Name-contains'id'){
   $Id=[string]$R.id
   if(-not[string]::IsNullOrWhiteSpace($Id)){
    if($Ids.ContainsKey($Id)){$Dup+=,$Id}else{$Ids[$Id]=$true}
   }
  }
 }
}
if($Records-ne349){throw ('Expected 349 records; found '+$Records)}
if(@($Dup|Select-Object -Unique).Count-ne0){throw 'Duplicate stable IDs detected.'}
foreach($M in @($Manifest)){
 $P=Join-Path $ReleaseRoot ([string]$M.path)
 if(-not(Test-Path -LiteralPath $P)){throw ('Missing manifest file: '+$M.path)}
 if((Get-FileHash -LiteralPath $P -Algorithm SHA256).Hash-ne$M.sha256){throw ('Hash mismatch: '+$M.path)}
}
Write-Host '[OK] RELEASE CANDIDATE VALIDATION PASS'
Write-Host '[OK] JSON files: 191'
Write-Host '[OK] Records: 349'
Write-Host '[OK] Duplicate IDs: 0'
