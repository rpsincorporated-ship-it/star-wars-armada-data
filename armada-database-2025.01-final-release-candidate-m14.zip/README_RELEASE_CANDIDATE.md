﻿# Star Wars: Armada Structured Data - Milestone 14 Release Candidate

Baseline: 2025.01-final

Official point-resolution transactions:
- Imperial I-class Star Destroyer: 112 -> 110 (Milestone 10)
- Onager-class Star Destroyer: 110 -> 120 (Milestone 14; AMG Errata 5.5 page 30)
- Onager-class Testbed: 96 -> 116 (Milestone 14; AMG Errata 5.5 page 30)
- Hera Syndulla 28 vs 23: resolved as distinct identities; no rewrite.

Official point confirmations remaining: 0
Campaign exact-text source gate: 19
Text-sensitive Errata source gate: 4
