﻿# Star Wars: Armada Structured Data - Release Candidate

Baseline: 2025.01-final

Milestone 10 official correction:
- Imperial I-class Star Destroyer: 112 -> 110

Remaining official point source gates:
- Onager-class Star Destroyer
- Onager-class Testbed
- Hera Syndulla

Campaign exact-text source gate: 19
Text-sensitive Errata source gate: 4
